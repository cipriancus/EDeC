package ro.oho.rest.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ro.oho.rest.model.SendMail;
import ro.oho.rest.model.User;
/**
 * Servlet implementation class ContactPage
 */
@WebServlet("/ContactPage")
public class ContactPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContactPage() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
    	RequestDispatcher rd = request.getRequestDispatcher("jsp/Contact.jsp");
		rd.forward(request, response);

    	response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		try{
			String name= request.getParameter("name");
			String email= request.getParameter("email");
			String pass= request.getParameter("password");
			String subiect= request.getParameter("subiect");
			String text= request.getParameter("mesaj");
			
			SendMail.send("aga.tandu.10@gmail.com",subiect, text,email, pass);
	        out.println("Mail send successfully");
			
		}
		finally
		{
			out.close();
		}
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processRequest(request, response);
	}

}
