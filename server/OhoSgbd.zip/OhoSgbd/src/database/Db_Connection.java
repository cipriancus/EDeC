package database;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Db_Connection 
{
	public Connection getOracleConnection() {
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","student","student");
	    return con;
		}
		catch(Exception exc)
		{
			exc.printStackTrace();
		}
		return null;
	  }
}
