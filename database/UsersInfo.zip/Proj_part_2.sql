set serveroutput on;
drop index usernameIndex;
/
CREATE INDEX usernameIndex ON UsersOho (username);
/
  EXPLAIN PLAN FOR
SELECT username FROM usersoho where username='admin';
 /
 SELECT PLAN_TABLE_OUTPUT FROM TABLE(DBMS_XPLAN.DISPLAY());
  /