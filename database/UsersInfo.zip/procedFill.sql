set serveroutput on;

drop table GroupPosts;
/
drop table Groupps;
/
drop table UserHobby;
/
drop table Hobby;
/
drop table grades;
/
drop table UsersOho;
/

create table UsersOho(
  idUser number, -- cheie primara
  nameUser varchar2(20) not null,
  surnameUser varchar2(30) not null,
  date_of_birth date,
  email varchar2(60) not null,
  username varchar2(50) not null,
  parola varchar2(32), -- poate sa nu treaca, generam noi parola
  grade number default 3, -- nu se trece, gradul e setat de admin/moderator
  CONSTRAINT pk_idUser primary key(idUser)
);
/

create table grades
(
  idGrad number,
  numeGrad varchar2(15)
);

insert into grades values (1, 'Administrator');
insert into grades values (2, 'Moderator');
insert into grades values (3, 'PowerUser');

create table UserHobby( -- cu trigger completez aceasta tabela
  idUser number, -- cheie straina
  idHobby number -- cheie straina
);
/

--trigger aici

create table Hobby(
  idHobby number,
  hobbyname varchar2(20),
  description varchar2(1500)
);
/

create or replace function passwordGenerator return varchar2 as
v_caracter varchar2(40);
v_rezultat varchar2(10);
begin
  v_caracter:='abcdefghijklmnopqrstuvwxyz0123456789';
  for i in 1..8 loop
    v_rezultat:=v_rezultat||substr(v_caracter,trunc(dbms_random.value(1,length(v_caracter)+1)),1);
  end loop;
  return v_rezultat;
end passwordGenerator;
/

declare
  v_n1 varchar2(20);
  v_n2 varchar2(20);
  v_count number:=1; -- ar cam da 1664 recorduri
  v_date_of_birth date;
begin
  --select count(*) into v_nrPrenume where p is not null;
  for i in (select * from numeFamSg) loop
    for j in (select * from numeSg) loop
      SELECT TO_DATE(TRUNC( DBMS_RANDOM.VALUE(TO_CHAR(DATE '1970-01-01','J') ,TO_CHAR(DATE '2011-01-01', 'J'))),'J') into v_date_of_birth FROM DUAL;
      INSERT INTO UsersOho values(v_count,i.nf, j.n,v_date_of_birth,lower(j.n||'.'||i.nf||'@oho.ro'), lower(j.n||'.'||i.nf), passwordGenerator,3);
      v_count:=v_count+1;
    end loop;
  end loop;
    INSERT INTO UsersOho values(v_count,'Popescu', 'Ionica',to_date('11-01-1988'),'ionica.popescu@oho.ro', 'ionica.popescu', passwordGenerator,2);
    v_count:=v_count+1;
    INSERT INTO UsersOho values(v_count,'Ionescu', 'Paul',to_date('12-02-1988'),'paul.ionescu@oho.ro', 'paul.ionescu', passwordGenerator,2);
    v_count:=v_count+1;
    INSERT INTO UsersOho values(v_count,'Aga', 'Alexandru',to_date('01-01-1995'),'alexandru.aga@oho.ro', 'alexandru.aga', 'alexa',1);
    v_count:=v_count+1;
    INSERT INTO UsersOho values(v_count,'Cusmuliuc', 'Ciprian',to_date('01-01-1995'),'ciprian.cusmuliuc@oho.ro', 'ciprian.cusmuliuc', 'ciprianc',1);
    v_count:=v_count+1;
    INSERT INTO UsersOho values(v_count,'Grosu','Ilie',to_date('01-01-1995'),'ilie.grosu@oho.ro', 'ilie.grosu', 'ilieg',1);
    v_count:=v_count+1;
    INSERT INTO UsersOho values(v_count,'Tanaselea','Alexandru',to_date('01-01-1995'),'alexandru.tanaselea@oho.ro', 'alexandru.tanaselea', 'alext',1);
    v_count:=v_count+1;
    INSERT INTO UsersOho values(v_count,'admin','admin',to_date('01-01-1995'),'admin@oho.ro', 'admin', 'admin',1);
    v_count:=v_count+1;
end;
/
-- va trebui sa creem si un user adevarat cu email valid pentru testare functie de parola uitata

/*select count(*) from UsersOho;
select * from UsersOho;
delete from UsersOho;
*/

INSERT INTO Hobby VALUES (1, 'Fotbal','Fotbalul este un sport de echip� ce se disput� �ntre dou� echipe alc�tuite din 11 juc�tori fiecare. La �nceputul secolului al XXI-lea era jucat de peste 250 de milioane de juc�tori �n peste 200 de ?�ri, ceea ce �l face cel mai popular sport din lume');
INSERT INTO Hobby VALUES (2, 'Box','Boxul (sau pugilismul) este un sport mar?ial str�vechi (probabil cel mai vechi sport mar?ial, cu origini preistorice), �n care doi concuren?i, cu greut�?i similare, lupt� cu ajutorul pumnilor, �ntr-o serie de reprize, numite runde. Victoria este ob?inut� in urma punctelor date pentru lovituri de catre juriu, sau atunci c�nd adversarul este dobor�t la p�m�nt ?i nu reu?e?te s� se ridice �nainte ca arbitrul s� termine de num�rat p�n� la 10, (englez� Knockout sau KO) sau c�nd adversarul este prea r�nit pentru a continua (englez� Technical Knockout sau TKO).');
INSERT INTO Hobby VALUES (3, 'Inot','�notul este o mi?care de deplasare a oamenilor sau a animalelor prin ap�, de obicei f�r� niciun fel de asisten?� artificial�. Tipurile sau stilurile de �not sunt craul, bras, fluture sau spate, dar ?i anumite derivate ale acestora, de exemplu bras lung, spate dublu etc.');
INSERT INTO Hobby VALUES (4, 'Baschet','Baschetul este unul dintre cele mai r�sp�ndite sporturi de echip� din lume; se caracterizeaz� prin fine?ea, precizia ?i fantezia exerci?iilor tehnice ?i tactice, prin talia �nalt� ?i calit�?ile fizice deosebite ale sportivilor, toate acestea implicate �ntr-o lupt� sportiv� care pretinde spirit de echip� ?i de sacrificiu, inteligen?� ?i rezisten?� nervoas�.');
INSERT INTO Hobby VALUES (5, 'Tenis','Tenisul este un sport jucat fie �ntre doi juc�tori (simplu), fie �ntre dou� echipe a c�te doi juc�tori (dublu). Juc�torii folosesc o rachet� pe baz� de racordaj pentru a lovi o minge de cauciuc acoperit� cu p�sl� peste fileu, mingea trebuind s� ajung� �n terenul adversarului.');
INSERT INTO Hobby VALUES (6, 'Pescuit','Pescuitul este activitatea de a prinde cu ajutorul unor instrumente speciale diverse variet�?i de pe?te sau alte viet�?i acvatice. Pescuitul mai poate fi considerat ca o extrac?ie a organismelor acvatice, din mediul �n care au crescut, cu diverse scopuri, precum alimentare, recreere (pescuit sportiv), ornamentare (captura speciilor ornamentale) sau ?eluri industriale.');
INSERT INTO Hobby VALUES (7, 'Dans','Dansul este un mijloc artistic de exprimare a unui mesaj printr-o succesiune de mi?c�ri ritmice, variate ?i expresive ale corpului, executate �n ritmul muzicii, av�nd caracter religios, de art� sau de divertisment.');
INSERT INTO Hobby VALUES (8, 'Muzica','Muzica (din gr. mousik?) este arta combin�rii notelor �n succesiune ?i simultan �ntr-o form� pl�cut� estetic, organizarea ritmic� a acestor note ?i integrarea lor �ntr-o lucrare complet�.');
INSERT INTO Hobby VALUES (9, 'Bucatarie','Buc�t�ria reprezint� arta ?i tehnica prepar�rii alimentelor destinate consumului uman. Buc�t�ria poate cuprinde toate no?iunile practice referitoare la ingrediente, prepararea lor, instrumentele folosite, modurile de g�tit ?i diferen?ele �ntre acestea. Este asociat� artei mesei ?i gastronomiei.');
INSERT INTO Hobby VALUES (10, 'Gradinarit','Gr�din�ritul reprezint� activitatea de cultivare a unor plante ornamentale sau nu �n spa?ii special amenajate (gr�dini). Gr�din�ritul poate fi realizat de amatori sau gr�dinari profesioni?ti.');



create table Groupps( -- i.e. Fotbal (in care am Fotbal clasic, fotbal amrican)
  idGroup number, -- cheie primara
  nameGroup varchar2(20),
  description varchar2(500)
);
/

create table GroupPosts( -- proiect cu caracter de socializare
  idHobby number,
  idUser number,
  message varchar2(500),
  date_of_post date default current_date
);
/
/*
insert into GroupPosts(idHobby, idUser, message) values(2,3,'ceva bun de tot');
select * from GroupPosts;*/
--procedura populare userHobby (ale celor 1kk)
declare
  v_nr number:=1;
  v_count number;
begin
  select count(*) into v_count from usersoho;
  for i in 1..v_count loop
    insert into UserHobby values (v_nr,trunc(dbms_random.value(1,11)));
    v_nr:=v_nr+1;
  end loop;
end;
/
select idhobby, count(*) as NrDoritori from userhobby group by idhobby order by NrDoritori desc;
/

--select * from studenti, note;

drop table users1;
/
create table users1(first_name varchar(20),last_name varchar(20),username varchar(20),password varchar(20),primary key(username));
/
insert into users1(first_name,last_name,username,password)
	values('Michael','Johnson','mike63','1234');
  /
  
  select * from users1;
  describe usersoho;
  
  
  create or replace function validatePassword(p_password varchar2) return number as
  v_flagCapital number:=0;
  v_flagLower number:=0;
  v_flagNumber number:=0;
  v_countLettersConfirm number:=0;
  begin
    if(length(p_password)<12) then return 0; end if;
    for i in 1..length(p_password) loop
      if(substr(p_password,i,1)>='A' and substr(p_password,i,1)<='Z') then v_flagCapital:=1; v_countLettersConfirm:=v_countLettersConfirm+1; end if;
      if(substr(p_password,i,1)>='a' and substr(p_password,i,1)<='z') then v_flagLower:=1; v_countLettersConfirm:=v_countLettersConfirm+1; end if;
      if(substr(p_password,i,1)>='0' and substr(p_password,i,1)<='9') then v_flagNumber:=1; v_countLettersConfirm:=v_countLettersConfirm+1; end if;
    end loop;
    dbms_output.put_line(v_countLettersConfirm);
    dbms_output.put_line(v_flagCapital);
    dbms_output.put_line(v_flagLower);
    dbms_output.put_line(v_flagNumber);
    if(v_countLettersConfirm=length(p_password) and v_flagCapital=1 and v_flagLower=1 and v_flagNumber=1) then return 1; end if;
    return 0;
  end validatePassword;
  /
  
  create or replace function validateFlName (p_name varchar2) return number as --validate first and last Name
   v_countLetters number:=0;
  begin
   for i in 1..length(p_name) loop
    if(substr(p_name,i,1)>='a' and substr(p_name,i,1)<='z') then v_countLetters:=v_countLetters+1; end if;
    if(substr(p_name,i,1)>='A' and substr(p_name,i,1)<='Z') then v_countLetters:=v_countLetters+1; end if;
   end loop;
   if(v_countLetters=length(p_name)) then return 1; end if;
  return 0;
  end validateFlName;
  
  create or replace function validateBirthDate(p_bd date) return number as
    v_oldy date:=to_date('01-01-1816');
  begin
    if (p_bd > v_oldy and p_bd<current_date) then return 1; end if;
      return 0;
  end validateBirthDate;
  
  create or replace function validateEmail(p_email varchar2) return number as
  v_positionAT number:=-1;
  v_positionDOT number:=-1;
  v_containsAT number:=0;
  v_containsDOT number:=0;
  begin
  for i in 1..length(p_email) loop
    if(substr(p_email,i,1)='@') then v_positionAT:=i; v_containsAT:=1; end if;
    if(substr(p_email,i,1)='.') then v_positionDOT:=i; v_containsDOT:=1; end if;
  end loop;
    if(v_containsAT=1 and v_containsDOT=1 and v_positionDOT-v_positionAT>=2 and v_positionDOT < length(p_email)-1) then return 1; end if;
  return 0;
  end validateEmail;
  
  create or replace function validateUsername(p_username varchar2) return number as
  v_copyP varchar2(50);
  v_countCaracters number:=0;
  begin
  v_copyP:=lower(p_username);
  for i in 1..length(v_copyP) loop
    if(substr(v_copyP,i,1)>='a' and substr(v_copyP,i,1)<='z') then v_countCaracters:=v_countCaracters+1; end if;
    if(substr(v_copyP,i,1)='.') then v_countCaracters:=v_countCaracters+1; end if;
  end loop;
  dbms_output.put_line(v_countCaracters);
  dbms_output.put_line(v_copyP);
  if(v_countCaracters=length(v_copyP)) then return 1; end if;
  return 0;
  end validateUsername;
  
  create or replace procedure addUser (p_nameUser varchar2, p_surnameUser varchar2, 
                                       p_dataBirth varchar2, p_email varchar2, p_userName varchar2, p_password varchar2) as
  v_variabila varchar2(30);
  begin
    -- aici sa adaugam exceptiile si validarile
  end addUser;
  
  declare
  v_ceva varchar2(20):='anaaremerealbastre1';
  v_nume varchar2(20):='popescu';
  v_prenume varchar2(20):='Ionica';
  v_date date:=to_date('21-05-1013');
  v_email varchar2(30):='id.ghg@falsyahoocom.as';
  v_user varchar2(20):='''alex.tanaseleAS';
  begin
    --dbms_output.put_line(validatePassword(v_ceva));
    --dbms_output.put_line(validateFlName(v_nume));
    --dbms_output.put_line(validateFlName(v_prenume));
    --dbms_output.put_line(VALIDATEBIRTHDATE(v_date));
    --dbms_output.put_line(validateEmail(v_email));
    dbms_output.put_line(validateUsername(v_user));
  end;