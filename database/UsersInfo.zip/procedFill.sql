set serveroutput on;

ALTER TABLE UserHobby DROP CONSTRAINT fk_UserHobby;
/
ALTER TABLE HobbyPost DROP CONSTRAINT fk_HobbyPost;
/
ALTER TABLE UsersOho DROP CONSTRAINT pk_idUser;
/
drop trigger autoincrementIdUser;
/
drop trigger autoincrementIdPost;
/
drop index usernameIndex;
/
drop index idHobbyIndex;
/
drop table HobbyPost;
/
drop table UserHobby;
/
drop table Hobby;
/
drop table grades;
/
drop table UsersOho;
/

create table UsersOho(
  idUser number default 0, -- cheie primara
  nameUser varchar2(20) not null,
  surnameUser varchar2(30) not null,
  date_of_birth date,
  email varchar2(60) not null,
  username varchar2(50) not null,
  parola varchar2(32), -- poate sa nu treaca, generam noi parola
  idGrad number default 2 -- nu se trece, gradul e setat de admin/moderator
);
/

create table grades
(
  idGrad number,
  numeGrad varchar2(15)
);
/
create table UserHobby( -- cu trigger completez aceasta tabela
  idUser number, -- cheie straina
  idHobby number -- cheie straina
);
/

create table Hobby(
  idHobby number,
  hobbyname varchar2(20),
  description varchar2(1500)
);
/

create table HobbyPost( -- proiect cu caracter de socializare
  idPost number default 0,
  idHobby number,
  idUser number,
  message varchar2(500),
  date_of_post date default current_date
);
/

CREATE OR REPLACE PACKAGE generator IS
     FUNCTION passwordGenerator return varchar2;
     PROCEDURE generateUsers;
     PROCEDURE generateHobbies;
     PROCEDURE generateUserHobby;
     PROCEDURE generateGrades;
END generator;
/
CREATE OR REPLACE PACKAGE BODY generator IS
  FUNCTION passwordGenerator RETURN varchar2 AS
    v_caracter varchar2(40);
    v_rezultat varchar2(10);
    begin
      v_caracter:='abcdefghijklmnopqrstuvwxyz0123456789';
      for i in 1..8 loop
        v_rezultat:=v_rezultat||substr(v_caracter,trunc(dbms_random.value(1,length(v_caracter)+1)),1);
      end loop;
    return v_rezultat;
END passwordGenerator;

  PROCEDURE generateUsers IS
    v_n1 varchar2(20);
    v_n2 varchar2(20);
    v_count number:=1; -- ar cam da 1664 recorduri
    v_date_of_birth date;
    BEGIN
      for i in (select * from numeFamSg) loop
        for j in (select * from numeSg) loop
          SELECT TO_DATE(TRUNC( DBMS_RANDOM.VALUE(TO_CHAR(DATE '1970-01-01','J') ,TO_CHAR(DATE '2011-01-01', 'J'))),'J') into v_date_of_birth FROM DUAL;
          INSERT INTO UsersOho values(v_count,i.nf, j.n,v_date_of_birth,lower(j.n||'.'||i.nf||'@oho.ro'), lower(j.n||'.'||i.nf), passwordGenerator,2);
          v_count:=v_count+1;
        end loop;
      end loop;
        INSERT INTO UsersOho values(v_count,'Aga', 'Alexandru',to_date('01-01-1995'),'alexandru.aga@oho.ro', 'alexandru.aga', 'alexa',1);
        v_count:=v_count+1;
        INSERT INTO UsersOho values(v_count,'Cusmuliuc', 'Ciprian',to_date('01-01-1995'),'ciprian.cusmuliuc@oho.ro', 'ciprian.cusmuliuc', 'ciprianc',1);
        v_count:=v_count+1;
        INSERT INTO UsersOho values(v_count,'Grosu','Ilie',to_date('01-01-1995'),'ilie.grosu@oho.ro', 'ilie.grosu', 'ilieg',1);
        v_count:=v_count+1;
        INSERT INTO UsersOho values(v_count,'Tanaselea','Alexandru',to_date('01-01-1995'),'alexandru.tanaselea@oho.ro', 'alexandru.tanaselea', 'alext',1);
        v_count:=v_count+1;
        INSERT INTO UsersOho values(v_count,'admin','admin',to_date('01-01-1995'),'admin@oho.ro', 'admin', 'admin',1);
        v_count:=v_count+1;
    END generateUsers;
    
    PROCEDURE generateHobbies IS
    BEGIN
      INSERT INTO Hobby VALUES (1, 'Fotbal','Fotbalul este un sport de echip� ce se disput� �ntre dou� echipe alc�tuite din 11 juc�tori fiecare. La �nceputul secolului al XXI-lea era jucat de peste 250 de milioane de juc�tori �n peste 200 de ?�ri, ceea ce �l face cel mai popular sport din lume');
      INSERT INTO Hobby VALUES (2, 'Box','Boxul (sau pugilismul) este un sport mar?ial str�vechi (probabil cel mai vechi sport mar?ial, cu origini preistorice), �n care doi concuren?i, cu greut�?i similare, lupt� cu ajutorul pumnilor, �ntr-o serie de reprize, numite runde. Victoria este ob?inut� in urma punctelor date pentru lovituri de catre juriu, sau atunci c�nd adversarul este dobor�t la p�m�nt ?i nu reu?e?te s� se ridice �nainte ca arbitrul s� termine de num�rat p�n� la 10, (englez� Knockout sau KO) sau c�nd adversarul este prea r�nit pentru a continua (englez� Technical Knockout sau TKO).');
      INSERT INTO Hobby VALUES (3, 'Inot','�notul este o mi?care de deplasare a oamenilor sau a animalelor prin ap�, de obicei f�r� niciun fel de asisten?� artificial�. Tipurile sau stilurile de �not sunt craul, bras, fluture sau spate, dar ?i anumite derivate ale acestora, de exemplu bras lung, spate dublu etc.');
      INSERT INTO Hobby VALUES (4, 'Baschet','Baschetul este unul dintre cele mai r�sp�ndite sporturi de echip� din lume; se caracterizeaz� prin fine?ea, precizia ?i fantezia exerci?iilor tehnice ?i tactice, prin talia �nalt� ?i calit�?ile fizice deosebite ale sportivilor, toate acestea implicate �ntr-o lupt� sportiv� care pretinde spirit de echip� ?i de sacrificiu, inteligen?� ?i rezisten?� nervoas�.');
      INSERT INTO Hobby VALUES (5, 'Tenis','Tenisul este un sport jucat fie �ntre doi juc�tori (simplu), fie �ntre dou� echipe a c�te doi juc�tori (dublu). Juc�torii folosesc o rachet� pe baz� de racordaj pentru a lovi o minge de cauciuc acoperit� cu p�sl� peste fileu, mingea trebuind s� ajung� �n terenul adversarului.');
      INSERT INTO Hobby VALUES (6, 'Pescuit','Pescuitul este activitatea de a prinde cu ajutorul unor instrumente speciale diverse variet�?i de pe?te sau alte viet�?i acvatice. Pescuitul mai poate fi considerat ca o extrac?ie a organismelor acvatice, din mediul �n care au crescut, cu diverse scopuri, precum alimentare, recreere (pescuit sportiv), ornamentare (captura speciilor ornamentale) sau ?eluri industriale.');
      INSERT INTO Hobby VALUES (7, 'Dans','Dansul este un mijloc artistic de exprimare a unui mesaj printr-o succesiune de mi?c�ri ritmice, variate ?i expresive ale corpului, executate �n ritmul muzicii, av�nd caracter religios, de art� sau de divertisment.');
      INSERT INTO Hobby VALUES (8, 'Muzica','Muzica (din gr. mousik?) este arta combin�rii notelor �n succesiune ?i simultan �ntr-o form� pl�cut� estetic, organizarea ritmic� a acestor note ?i integrarea lor �ntr-o lucrare complet�.');
      INSERT INTO Hobby VALUES (9, 'Bucatarie','Buc�t�ria reprezint� arta ?i tehnica prepar�rii alimentelor destinate consumului uman. Buc�t�ria poate cuprinde toate no?iunile practice referitoare la ingrediente, prepararea lor, instrumentele folosite, modurile de g�tit ?i diferen?ele �ntre acestea. Este asociat� artei mesei ?i gastronomiei.');
      INSERT INTO Hobby VALUES (10, 'Gradinarit','Gr�din�ritul reprezint� activitatea de cultivare a unor plante ornamentale sau nu �n spa?ii special amenajate (gr�dini). Gr�din�ritul poate fi realizat de amatori sau gr�dinari profesioni?ti.');
    END generateHobbies;
    
    PROCEDURE generateUserHobby IS
    v_nr number:=1;
    v_count number;
    v_countHobbies number;
    BEGIN
      select count(*) into v_count from usersoho;
      select count(*) into v_countHobbies from Hobby;
      for i in 1..v_count loop
        insert into UserHobby values (v_nr,trunc(dbms_random.value(1, v_countHobbies+1)));
        v_nr:=v_nr+1;
      end loop;
    END generateUserHobby;
    
    PROCEDURE generateGrades IS
    BEGIN
      insert into grades values (1, 'Administrator');
      insert into grades values (2, 'PowerUser');
    END generateGrades;
END generator;
/

CREATE OR REPLACE PACKAGE validator IS
     FUNCTION validateFlName (p_name varchar2) return number;
     FUNCTION validatePassword (p_password varchar2) return number;
     FUNCTION validateBirthDate (p_bd date) return number;
     FUNCTION validateEmail (p_email varchar2) return number;
     FUNCTION validateUsername (p_username varchar2) return number;
END validator;
/

CREATE OR REPLACE PACKAGE BODY validator IS
    null_parameter EXCEPTION;
        PRAGMA EXCEPTION_INIT(null_parameter, -20060);
    v_error varchar2(40):='Parametrul functiei de validare nu poate fi null.';
        
    FUNCTION validateFlName (p_name varchar2) RETURN number AS
       v_countLetters number:=0;
    BEGIN
      if(p_name is null) then raise null_parameter;
        else
         for i in 1..length(p_name) loop
          if(substr(p_name,i,1)>='a' and substr(p_name,i,1)<='z') then v_countLetters:=v_countLetters+1; end if;
          if(substr(p_name,i,1)>='A' and substr(p_name,i,1)<='Z') then v_countLetters:=v_countLetters+1; end if;
         end loop;
         if(v_countLetters=length(p_name)) then return 1; end if;
       end if;
       return 0;
       EXCEPTION
            WHEN null_parameter THEN
              raise_application_error (-20060,v_error);
    END validateFlName;
    
    FUNCTION validatePassword(p_password varchar2) return number as
      v_flagCapital number:=0;
      v_flagLower number:=0;
      v_flagNumber number:=0;
      v_countLettersConfirm number:=0;
      BEGIN
        if(length(p_password)<12) then return 0; end if;
        for i in 1..length(p_password) loop
          if(substr(p_password,i,1)>='A' and substr(p_password,i,1)<='Z') then v_flagCapital:=1; v_countLettersConfirm:=v_countLettersConfirm+1; end if;
          if(substr(p_password,i,1)>='a' and substr(p_password,i,1)<='z') then v_flagLower:=1; v_countLettersConfirm:=v_countLettersConfirm+1; end if;
          if(substr(p_password,i,1)>='0' and substr(p_password,i,1)<='9') then v_flagNumber:=1; v_countLettersConfirm:=v_countLettersConfirm+1; end if;
        end loop;
        if(v_countLettersConfirm=length(p_password) and v_flagCapital=1 and v_flagLower=1 and v_flagNumber=1) then return 1; end if;
        return 0;
  END validatePassword;
    
    FUNCTION validateBirthDate(p_bd date) return number as
      v_oldy date:=to_date('01-01-1816');
    BEGIN
      if (p_bd > v_oldy and p_bd<current_date) then return 1; end if;
        return 0;
    END validateBirthDate;
    
    FUNCTION validateEmail(p_email varchar2) return number as
      v_positionAT number:=-1;
      v_positionDOT number:=-1;
      v_containsAT number:=0;
      v_containsDOT number:=0;
      BEGIN
      if(p_email is null) then raise null_parameter;
        else
          for i in 1..length(p_email) loop
            if(substr(p_email,i,1)='@') then v_positionAT:=i; v_containsAT:=1; end if;
            if(substr(p_email,i,1)='.') then v_positionDOT:=i; v_containsDOT:=1; end if;
          end loop;
            if(v_containsAT=1 and v_containsDOT=1 and v_positionDOT-v_positionAT>=2 and v_positionDOT < length(p_email)-1) then return 1; end if;
      end if;
      return 0;
      EXCEPTION
            WHEN null_parameter THEN
              raise_application_error (-20060,v_error);
      END validateEmail;
      
      FUNCTION validateUsername(p_username varchar2) return number as
        v_copyP varchar2(50);
        v_countCaracters number:=0;
        BEGIN
        if(p_username is null) then raise null_parameter;
          else
            v_copyP:=lower(p_username);
            for i in 1..length(v_copyP) loop
              if(substr(v_copyP,i,1)>='a' and substr(v_copyP,i,1)<='z') then v_countCaracters:=v_countCaracters+1; end if;
              if(substr(v_copyP,i,1)='.') then v_countCaracters:=v_countCaracters+1; end if;
            end loop;
            if(v_countCaracters=length(v_copyP)) then return 1; end if;
        end if;
        return 0;
        EXCEPTION
              WHEN null_parameter THEN
                raise_application_error (-20060, v_error);
        END validateUsername;
END validator;
/

begin -- pentru initializarea informatiilor
    GENERATOR.GENERATEGRADES();
    GENERATOR.GENERATEUSERS();
    GENERATOR.GENERATEHOBBIES();
    GENERATOR.GENERATEUSERHOBBY();
end;
/

  ALTER TABLE UsersOho
  ADD CONSTRAINT pk_idUser PRIMARY KEY (idUser);
  /

  ALTER TABLE UserHobby ADD CONSTRAINT fk_UserHobby FOREIGN KEY (idUser)
  REFERENCES UsersOho(idUser) ON DELETE CASCADE;
  /
  
  ALTER TABLE HobbyPost ADD CONSTRAINT fk_HobbyPost FOREIGN KEY (idUser)
  REFERENCES UsersOho(idUser) ON DELETE CASCADE;
  /
  
   /* CREATE INDEX idUserIndex-- e deja index ca e cheie primara
    ON UsersOho (idUser);*/
    
CREATE INDEX usernameIndex ON UsersOho (username);
/

CREATE INDEX idHobbyIndex ON HobbyPost (idHobby);
/

 create or replace trigger autoincrementIdUser after insert on UsersOho
  declare
    v_lastid number;
  begin
    select max(idUser) into v_lastid from usersoho;
    update UsersOho set idUser=v_lastid+1 where idUser=0;
  end;
 /
 
 create or replace trigger autoincrementIdPost after insert on HobbyPost
  declare
    v_lastid number;
  begin
    select max(idPost) into v_lastid from hobbypost;
    update hobbypost set idPost=v_lastid+1 where idPost=0;
  end;
 /
 

CREATE OR REPLACE PACKAGE userSkills IS
     PROCEDURE addUser(p_nameUser varchar2, p_surnameUser varchar2, 
                                       p_dataBirth varchar2, p_email varchar2, p_userName varchar2, p_password varchar2);
     PROCEDURE joinToNewHobby(p_username varchar2, p_nameHobby varchar2);
     PROCEDURE postIt(p_username varchar2, p_hobby varchar2, p_message varchar2);
     PROCEDURE updateUser(p_username varchar2, p_name varchar2, p_surname varchar2, p_date_of_birth varchar2, p_email varchar2, p_password varchar2);
END userSkills;
/

CREATE OR REPLACE PACKAGE BODY userSkills IS
  nume_invalid EXCEPTION;
    PRAGMA EXCEPTION_INIT(nume_invalid, -20002);
  prenume_invalid EXCEPTION;
    PRAGMA EXCEPTION_INIT(prenume_invalid, -20003);
  data_nasterii_invalida EXCEPTION;
    PRAGMA EXCEPTION_INIT(data_nasterii_invalida, -20004);
  email_invalid EXCEPTION;
    PRAGMA EXCEPTION_INIT(email_invalid, -20005);
  parola_invalida EXCEPTION;
    PRAGMA EXCEPTION_INIT(parola_invalida, -20006);  

    PROCEDURE addUser (p_nameUser varchar2, p_surnameUser varchar2, 
                                       p_dataBirth varchar2, p_email varchar2, p_userName varchar2, p_password varchar2) IS
  user_existent EXCEPTION;
    PRAGMA EXCEPTION_INIT(user_existent, -20001);
  user_invalid EXCEPTION;
    PRAGMA EXCEPTION_INIT(user_invalid, -20007);
    v_flag number;
    v_nrRowsSameUsername number;
  BEGIN
    v_flag:=validator.validateFlName(p_nameUser);
    if(v_flag=0) then raise nume_invalid;
      else
        v_flag:=validator.validateFlName(p_surnameUser);
        if(v_flag=0) then raise prenume_invalid;
        else
          v_flag:=validator.validateBirthDate(p_dataBirth);
          if(v_flag=0) then raise data_nasterii_invalida;
          else
            v_flag:=validator.validateEmail(p_email);
            if(v_flag=0) then raise email_invalid;
            else
              v_flag:=validator.validateUsername(p_userName);
              if(v_flag=0) then raise user_invalid;
              else
                select count(*) into v_nrRowsSameUsername from usersoho where username=p_userName;
                if(v_nrRowsSameUsername>0) then raise user_existent;
                else
                  if(p_password is null) then 
                    insert into usersoho values (0, p_nameUser, p_surnameUser, p_dataBirth, p_email, p_userName,generator.passwordGenerator(), 2);
                    else
                    v_flag:=validator.validatePassword(p_password);
                    if(v_flag=0) then raise parola_invalida;
                      else
                        insert into usersoho values (0, p_nameUser, p_surnameUser, p_dataBirth, p_email, p_userName,p_password, 2);
                    end if;
                  end if;
                end if;
              end if;
            end if;
          end if;
        end if;
    end if;
    EXCEPTION
        WHEN nume_invalid THEN
          raise_application_error (-20002,'Numele ' || p_nameUser || ' nu poate fi adaugat in baza de date.');
          WHEN prenume_invalid THEN
          raise_application_error (-20003,'Prenumele ' || p_surnameUser || ' nu poate fi adaugat in baza de date.');
          WHEN data_nasterii_invalida THEN
          raise_application_error (-20004,'Data ' || p_dataBirth || ' nu poate fi adaugata in baza de date.');
          WHEN email_invalid THEN
          raise_application_error (-20005,'Email-ul ' || p_email || ' nu poate fi adaugat in baza de date.');
          WHEN user_existent THEN
          raise_application_error (-20001,'Numele de utilizator ' || p_userName || ' nu poate fi adaugat in baza de date.');
          WHEN parola_invalida THEN
          raise_application_error (-20006,'Parola trebuie sa contina: minim 12 caractere, litere mici, litere mari si cifre!!!');
          WHEN user_invalid THEN
          raise_application_error (-20007, 'Numele de logare '||p_userName||' nu poate fi adaugat in baza de date.');
  END addUser;
    
    PROCEDURE joinToNewHobby(p_username varchar2, p_nameHobby varchar2) as
          denumire_hobby_invalida EXCEPTION;
            PRAGMA EXCEPTION_INIT(denumire_hobby_invalida, -20010);
          hobby_inexistent EXCEPTION;
            PRAGMA EXCEPTION_INIT(hobby_inexistent, -20011);
          username_inexistent EXCEPTION;
            PRAGMA EXCEPTION_INIT(username_inexistent, -20012);
            v_existHobby number;
            v_rightName number;
            v_existUser number;
        BEGIN
          select count(*) into v_existUser from UsersOho where username=p_username;
          if(v_existUser=0) then raise username_inexistent;
            else
            v_rightName:=validator.validateFlName(p_nameHobby);
            if(v_rightName=0) then raise denumire_hobby_invalida;
              else
              select count(*) into v_existHobby from Hobby where hobbyname=p_nameHobby;
              if(v_existHobby=0) then raise hobby_inexistent;
                else
                  select idUser into v_existUser from UsersOho where username=p_username;
                  select idHobby into v_rightName from Hobby where hobbyname=p_nameHobby;-- rescriu valoarea lui v_rightName si pun in aceasta variabila
                  insert into userhobby values(v_existUser, v_rightName);                    -- id-ul hobbiului dorit
              end if;
            end if;
        end if;
        EXCEPTION
              WHEN denumire_hobby_invalida THEN
                raise_application_error (-20010,'Denumire hobby invalida.');
              WHEN hobby_inexistent THEN
                raise_application_error (-20011, 'Hobby-ul cu numele '|| p_nameHobby || ' nu exista in baza de date.');
              WHEN username_inexistent THEN
                raise_application_error (-20012, 'Userul ' || p_username || ' este invalid');
        END joinToNewHobby;
    
    PROCEDURE postIt(p_username varchar2, p_hobby varchar2, p_message varchar2) as
        username_inexistent EXCEPTION;
            PRAGMA EXCEPTION_INIT(username_inexistent, -20040);
        username_invalid EXCEPTION;
            PRAGMA EXCEPTION_INIT(username_invalid, -20041);
        denumire_hobby_invalida EXCEPTION;
          PRAGMA EXCEPTION_INIT(denumire_hobby_invalida, -20042);
        hobby_inexistent EXCEPTION;
          PRAGMA EXCEPTION_INIT(hobby_inexistent, -20043);
        hobby_necorespunzator EXCEPTION;
          PRAGMA EXCEPTION_INIT(hobby_necorespunzator, -20044);
          v_flag number;
          v_idHobby number;
          v_idUser number;
      BEGIN
        v_flag:=validator.validateUsername(p_username);
        if(v_flag=0) then raise username_invalid;
        else
          select count(*) into v_flag from usersoho where username=p_username;
          if(v_flag=0) then raise username_inexistent;
          else
            v_flag:=validator.validateFlName(p_hobby);
            if(v_flag=0) then raise denumire_hobby_invalida;
            else
              select count(*) into v_flag from Hobby where hobbyname=p_hobby;
              if(v_flag=0) then raise hobby_inexistent;
              else
                select idUser into v_idUser from usersoho where username=p_username;
                select idHobby into v_idHobby from hobby where hobbyname=p_hobby;
                select count(*) into v_flag from userhobby where idUser=v_idUser and idHobby=v_idHobby;
                if(v_flag=0) then raise hobby_necorespunzator;
                else
                  insert into hobbypost values(0,v_idHobby, v_idUser, p_message, current_date);
                end if;
              end if;
            end if;
          end if;
        end if;
        EXCEPTION
            WHEN username_invalid THEN
              raise_application_error (-20040,'Numele de utilizator '|| p_username || ' este invalid.');
            WHEN username_inexistent THEN
              raise_application_error (-20041, 'Numele de utilizator '|| p_username || ' nu exista in baza de date.');
            WHEN denumire_hobby_invalida THEN
              raise_application_error (-20042,'Hobby-ul cu numele '|| p_hobby || ' nu poate fi adaugat in baza de date.');
            WHEN hobby_inexistent THEN
              raise_application_error (-20043,'Hobby-ul cu numele '|| p_hobby || ' nu exista in baza de date.');
            WHEN hobby_necorespunzator THEN
              raise_application_error (-20044, 'Userul '|| p_username || ' nu poate posta in hobby-ul ' || p_hobby || ' .');
      END postIt;
      
    PROCEDURE updateUser(p_username varchar2, p_name varchar2, p_surname varchar2, 
                            p_date_of_birth varchar2, p_email varchar2, p_password varchar2) AS
  
        username_inexistent EXCEPTION;
            PRAGMA EXCEPTION_INIT(username_inexistent, -20050);
        username_invalid EXCEPTION;
            PRAGMA EXCEPTION_INIT(username_invalid, -20051);
        v_CursorID  NUMBER; -- Variable assigned to value from OPEN_CURSOR
        v_CreateTableString  VARCHAR2(500); -- SQL stored as string to create table
        v_NUMRows  INTEGER; -- Number of rows processed - of no use
        v_flag number;
        v_set varchar2(500):='';
      BEGIN
        v_flag:=validator.validateUsername(p_username);
        if(v_flag=0) then raise username_invalid;
          else
          select count(*) into v_flag from usersoho where username=p_username;
          if(v_flag=0) then raise username_inexistent;
            else
            if(p_name is not null) then
              if(validator.validateFlName(p_name)=0) then raise nume_invalid;
              else
                v_set:=v_set||' nameuser = '''||p_name||''' ,';
              end if;
            end if;
           if(p_surname is not null) then
            if(validator.validateFlName(p_surname)=0) then raise prenume_invalid;
            else
              v_set:=v_set||' surnameuser = '''||p_surname||''' ,';
            end if;
           end if;
           if(p_email is not null) then
            if(validator.validateEmail(p_email)=0) then raise email_invalid;
            else
              v_set:=v_set||' email = '''||p_email||''' ,';
            end if;
           end if;
           if(p_date_of_birth is not null) then
            if(validator.validateBirthDate(p_date_of_birth)=0) then raise data_nasterii_invalida;
            else
              v_set:=v_set||' date_of_birth = '''||p_date_of_birth||''' ,';
            end if;
           end if;
           if(p_password is not null) then
            if(validator.validatePassword(p_password)=0) then raise parola_invalida;
            else
              v_set:=v_set||' parola = '''||p_password||''' ,';
            end if;
           end if;
           v_set:=substr(v_set, 0, length(v_set)-2);
           v_CursorID := DBMS_SQL.OPEN_CURSOR; -- Get the Cursor ID
           v_CreateTableString := ' UPDATE UsersOho SET' || v_set || ' WHERE username= '''|| p_username ||'''';
            -- Write SQL code to create table  -- pun un A in fata, nu vrea sa recunoasca un numar ca nume de tabela
           DBMS_SQL.PARSE(v_CursorID,v_CreateTableString,DBMS_SQL.V7);
               /* Perform syntax error checking */
           v_NumRows := DBMS_SQL.EXECUTE(v_CursorID);
              /* Execute the SQL code  */
           DBMS_SQL.CLOSE_CURSOR(v_CursorID); -- Close the cursor
          end if;
        end if;
        EXCEPTION
            WHEN username_invalid THEN
              raise_application_error (-20050,'Numele de utilizator '|| p_username || ' este invalid.');
            WHEN username_inexistent THEN
              raise_application_error (-20051, 'Numele de utilizator '|| p_username || ' nu exista in baza de date.');
            WHEN nume_invalid THEN
              raise_application_error (-20002,'Numele ' || p_name || ' nu poate fi adaugat in baza de date.');
            WHEN prenume_invalid THEN
              raise_application_error (-20003,'Prenumele ' || p_surname || ' nu poate fi adaugat in baza de date.');
            WHEN data_nasterii_invalida THEN
              raise_application_error (-20004,'Data ' || p_date_of_birth || ' nu poate fi adaugata in baza de date.');
            WHEN email_invalid THEN
              raise_application_error (-20005,'Email-ul ' || p_email || ' nu poate fi adaugat in baza de date.');
            WHEN parola_invalida THEN
              raise_application_error (-20006,'Parola trebuie sa contina: minim 12 caractere, litere mici, litere mari si cifre!!!');
      END updateUser;
END userSkills;
/
 
CREATE OR REPLACE PACKAGE adminSkills IS
     PROCEDURE setGrade(p_username varchar2, p_grade varchar2);
     PROCEDURE deleteUser(p_username varchar2);
END adminSkills;
/

CREATE OR REPLACE PACKAGE BODY adminSkills IS
    username_inexistent EXCEPTION;
        PRAGMA EXCEPTION_INIT(username_inexistent, -20030);
    username_invalid EXCEPTION;
        PRAGMA EXCEPTION_INIT(username_invalid, -20031);
      
    PROCEDURE setGrade(p_username varchar2, p_grade varchar2) as
        grad_inexistent EXCEPTION;
            PRAGMA EXCEPTION_INIT(grad_inexistent, -20020);
        denumire_grad_invalida EXCEPTION;
            PRAGMA EXCEPTION_INIT(denumire_grad_invalida, -20021);
        v_corectName number;
      BEGIN
        v_corectName:=validator.validateUsername(p_username);
            if(v_corectName=0) then raise username_invalid;
            else
              select count(*) into v_corectName from UsersOho where username=p_username;
              if(v_corectName = 0) then raise username_inexistent;
              else
              v_corectName:=validator.validateFlName(p_grade);
              if(v_corectName=0) then raise denumire_grad_invalida;
                else
                  select count(*) into v_corectName from grades where numegrad=p_grade;
                  if(v_corectName=0) then raise grad_inexistent;
                    else
                      select idGrad into v_corectName from grades where numegrad=p_grade;
                      update UsersOho set idGrad=v_corectName where username=p_username;
                  end if;
              end if;
            end if;
          end if;
        EXCEPTION
            WHEN username_invalid THEN
              raise_application_error (-20031,'Numele de utilizator '|| p_username || ' este invalid.');
            WHEN username_inexistent THEN
              raise_application_error (-20030, 'Numele de utilizator '|| p_username || ' nu exista in baza de date.');
            WHEN denumire_grad_invalida THEN
              raise_application_error (-20022,'Nume grad invalid.');
            WHEN grad_inexistent THEN
              raise_application_error (-20023, 'Gradul ' || p_grade || ' nu exista in baza de date.');
      END setGrade;
    
    PROCEDURE deleteUser(p_username varchar2) as
        v_flag number;
      BEGIN
        v_flag:=validator.validateUsername(p_username);
        if(v_flag=0) then raise username_invalid;
          else
          select count(*) into v_flag from usersoho where username=p_username;
          if(v_flag=0) then raise username_inexistent;
          else
            delete from UsersOho where username=p_username;
          end if;
        end if;
      EXCEPTION
            WHEN username_invalid THEN
              raise_application_error (-20030,'Numele de utilizator '|| p_username || ' este invalid.');
            WHEN username_inexistent THEN
              raise_application_error (-20031, 'Numele de utilizator '|| p_username || ' nu exista in baza de date.');  
      END deleteUser;
END adminSkills;   
/