set serveroutput on;

create table UsersOho(
  idUser number unique, -- cheie primara
  nameUser varchar2(20),
  surnameUser varchar2(30),
  date_of_birth date,
  email varchar2(20),
  username varchar2(15),
  parola varchar2(32)
);


declare
  v_n1 varchar2(20);
  v_n2 varchar2(20);
  v_count number:=1; -- ar cam da 1664 recorduri
 /* v_nrPrenume number;
  v_lastMatricol number;
  v_randomAn number;
  v_randomGrupa number;
  v_randomBursa number;
  v_randomNota number;*/
begin
  --select count(*) into v_nrPrenume where p is not null;
  for i in (select * from numeFamSg) loop
    for j in (select * from numeSg) loop
          INSERT INTO UsersOho(idUser, nameUser, surnameUser) values(v_count,i.nf, j.n);
          v_count:=v_count+1;
    end loop;
  end loop;
--dbms_output.put_line(v_n1||' - '||v_n2);
end;

select count(*) from UsersOho;
select * from UsersOho;