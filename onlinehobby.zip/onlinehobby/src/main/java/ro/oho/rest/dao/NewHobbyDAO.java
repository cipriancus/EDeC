package ro.oho.rest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ro.oho.rest.model.ConnectionHelperClass;
import ro.oho.rest.model.Hobby;
public class NewHobbyDAO {

	private static final String GET_ALL_NEW_HOBBY= "select * from hobby where approved=0";
	private static final String UPDATE_HOBBY= "update hobby set approved=1 where hobbyname=?";
	private static final String DELETE_HOBBY= "delete from  hobby where hobbyname=?";
	
	public static List<String> getAllHobby() throws SQLException
	{
		Connection con = ConnectionHelperClass.getOracleConnection();
		PreparedStatement prepareStatement = con.prepareStatement(GET_ALL_NEW_HOBBY);
		ResultSet resultSet = prepareStatement.executeQuery();
		List<String> allHobby=new ArrayList<String>();
		while(resultSet.next()){
			allHobby.add(resultSet.getString("hobbyname"));
		}
		
		return allHobby;

	}
	public static void updateHobby(String hobbyName)
	{
		Connection con = ConnectionHelperClass.getOracleConnection();
		try {
			PreparedStatement prepareStatement = con.prepareStatement(UPDATE_HOBBY);
			prepareStatement.setString(1, hobbyName);
			prepareStatement.executeQuery();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static void deleteHobby(String hobbyName)
	{
		Connection con = ConnectionHelperClass.getOracleConnection();
		try {
			PreparedStatement prepareStatement = con.prepareStatement(DELETE_HOBBY);
			prepareStatement.setString(1, hobbyName);
			prepareStatement.executeQuery();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
