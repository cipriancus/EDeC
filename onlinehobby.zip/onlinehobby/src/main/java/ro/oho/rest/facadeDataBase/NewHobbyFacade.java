package ro.oho.rest.facadeDataBase;
import java.sql.SQLException;
import java.util.List;

import ro.oho.rest.dao.NewHobbyDAO;


public class NewHobbyFacade {

	public List<String> getAllNewHobby() throws SQLException
	{
		
		return NewHobbyDAO.getAllHobby();
		
	}
	
}
